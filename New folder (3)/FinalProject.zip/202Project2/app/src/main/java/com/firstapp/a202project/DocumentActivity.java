package com.firstapp.a202project;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;

public class DocumentActivity extends AppCompatActivity {

       string filePath = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_document);

        PDFView pdfView = findViewById(R.id.pdfView);
        filePath = getIntent().getStringExtra(name: "path");

        File file =  new File(filePath);
        Uri path = Uri.fromFile(file);
        pdfView.fromUri(path).Load();
    }
}