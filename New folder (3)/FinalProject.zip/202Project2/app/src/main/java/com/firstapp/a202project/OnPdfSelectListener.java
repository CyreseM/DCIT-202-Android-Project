package com.firstapp.a202project;

import android.os.Bundle;

import java.io.File;

public interface OnPdfSelectListener {
    void OnPdfSelected(File file);

    abstract void onCreate(Bundle savedInstanceState);
}
